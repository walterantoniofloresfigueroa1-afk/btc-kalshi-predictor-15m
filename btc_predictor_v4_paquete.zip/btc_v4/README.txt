BTC Predictor V4 — GitHub Actions + GitHub Pages

Sube estos archivos respetando sus rutas:
  .github/workflows/btc-v4.yml
  scripts/update.py
  btc_predictor_v4.html

En GitHub, Actions > BTC Predictor V4 - Simulacion > Run workflow.
El flujo creará data/signals.json y lo actualizará con las ejecuciones programadas.
En Settings > Actions > General, confirma que Workflow permissions permite Read and write permissions (si la política del repositorio lo permite).
Abre la página https://TU-USUARIO.github.io/TU-REPO/btc_predictor_v4.html

Advertencias: GitHub Actions schedule es best-effort: puede retrasarse, deshabilitarse por inactividad y no equivale a un servidor siempre activo. Si se omite una ejecución, no se reconstruyen todas las señales perdidas. Los resultados usan velas Coinbase de 5 minutos, no liquidación Kalshi. El historial es público en repositorios públicos. Sin garantías de precisión o ganancias.
